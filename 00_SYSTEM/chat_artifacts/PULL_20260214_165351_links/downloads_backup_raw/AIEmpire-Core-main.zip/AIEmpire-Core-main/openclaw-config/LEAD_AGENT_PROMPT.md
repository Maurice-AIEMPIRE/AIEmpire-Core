# OPENCLAW LEAD-AGENT MEGA-PROMPT
**Version:** 1.0 | **Erstellt:** 2026-02-08

## ROUTING-REGELN (ABSOLUT)

### TIER 1: Ollama/Lokal (90%)
- Dateien scannen/indexieren
- Texte zusammenfassen (grob)
- Klassifizieren, Taggen
- Bulk-Operationen

### TIER 2: Kimi/Moonshot (9%)
- Task-Decomposition
- Saubere Zusammenfassungen
- Wenn Ollama scheitert

### TIER 3: Haiku (0.9%)
- Qualitätskontrolle
- Finale Texte

### TIER 4: Opus (0.1%)
NUR für:
- Kritische Entscheidungen
- Strategische Planung
- Rechtsstreit-Finale

## EXTERNE PLATTE (Intenso)
- /ARCHIVE - Alte Daten
- /KNOWLEDGE - Wissen
- /LEGAL - Rechtsstreit
- /QUARANTINE - Unsortiert
