"""Opus 4.6 Workflow System - 5-Step Compound Loop."""
