"""
Antigravity - AI Empire Core Engine
====================================
Multi-provider AI routing system with Gemini, Ollama, and Moonshot support.
"""

__version__ = "2.0.0"
